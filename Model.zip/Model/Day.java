package Model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Day {
    private int dayOfMonth;
    private Event[] events;
    private int size;

    public Day(int dayOfMonth) {
        this.dayOfMonth = dayOfMonth;
        this.events = new Event[0];
        this.size = 0;
    }

    public void addEvent(Event event) {
        if (size == events.length) {
            events = Arrays.copyOf(events, size + 1);
        }
        events[size++] = event;
    }

    public void removeEvent(String eventName) {
        for (int i = 0; i < size; i++) {
            if (events[i] instanceof Event && events[i].getName().equals(eventName)) {
                System.arraycopy(events, i + 1, events, i, size - i - 1);
                size--;
                return;
            }
        }
        System.out.println("Event '" + eventName + "' not found.");
    }

    public int getDayOfMonth() {
        return dayOfMonth;
    }

    public Event[] getEvents() {
        return Arrays.copyOf(events, size);
    }

    public int size() {
        return size;
    }

    public boolean hasEvents() {
        return size > 0;
    }
}
