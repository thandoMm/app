package Model;

import java.util.Scanner;

public class Calendar {

	public static void main(String[] args) {
		  Month january = new Month("January", 31);
	        january.addEvent(1, new Event("New Year's Day"));
	        january.addEvent(5, new Event("Team Lunch"));
	        january.addEvent(10, new Event("Meeting with Client"));

	        Scanner scanner = new Scanner(System.in);
	        int choice;
	        do {
	            january.viewFullMonth();
	            System.out.println("\n1. View events for a specific day");
	            System.out.println("2. Add an event");
	            System.out.println("3. Remove an event");
	            System.out.println("4. Exit");
	            System.out.print("Enter your choice: ");
	            choice = scanner.nextInt();
	            switch (choice) {
	                case 1:
	                    System.out.print("Enter the day number to view events: ");
	                    int day = scanner.nextInt();
	                    january.viewEvents(day);
	                    break;
	                case 2:
	                    System.out.print("Enter the day number to add event to: ");
	                    int dayToAdd = scanner.nextInt();
	                    scanner.nextLine(); // Consume newline
	                    System.out.print("Enter the event name to add: ");
	                    String eventName = scanner.nextLine();
	                    january.addEvent(dayToAdd, new Event(eventName));
	                    break;
	                case 3:
	                    System.out.print("Enter the day number to remove event from: ");
	                    int dayToRemove = scanner.nextInt();
	                    scanner.nextLine(); // Consume newline
	                    System.out.print("Enter the event name to remove: ");
	                    String eventToRemove = scanner.nextLine();
	                    january.removeEvent(dayToRemove, eventToRemove);
	                    break;
	                case 4:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        } while (choice != 4);
	        scanner.close();
	}
	
}
