package Model;

import java.util.ArrayList;
import java.util.List;

public class Month {
	  private String name;
	    private Day[] days;
	    private int size;

	    public Month(String name, int numOfDays) {
	        this.name = name;
	        this.days = new Day[numOfDays];
	        this.size = numOfDays;
	        for (int i = 0; i < numOfDays; i++) {
	            this.days[i] = new Day(i + 1);
	        }
	    }

	    public void addEvent(int day, Event event) {
	        if (day < 1 || day > size) {
	            throw new IllegalArgumentException("Invalid day number");
	        }
	        ensureCapacity(day);
	        this.days[day - 1].addEvent(event);
	    }

	    private void ensureCapacity(int day) {
	        if (day > size) {
	            Day[] newArray = new Day[day];
	            System.arraycopy(days, 0, newArray, 0, size);
	            for (int i = size; i < day; i++) {
	                newArray[i] = new Day(i + 1);
	            }
	            size = day;
	            days = newArray;
	        }
	    }

	    public void removeEvent(int day, String eventName) {
	        this.days[day - 1].removeEvent(eventName);
	    }

	    public void viewFullMonth() {
	        System.out.println("Calendar for " + name);
	        System.out.println("Sun Mon Tue Wed Thu Fri Sat");
	        int dayIndex = 0;
	        for (int week = 0; week < 6; week++) {
	            for (int dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
	                if (dayIndex < days.length) {
	                    Day day = days[dayIndex];
	                    if (day.hasEvents()) {
	                        System.out.printf("*%2d ", day.getDayOfMonth());
	                    } else {
	                        System.out.printf(" %2d ", day.getDayOfMonth());
	                    }
	                    dayIndex++;
	                } else {
	                    System.out.print("    ");
	                }
	            }
	            System.out.println();
	        }
	    }

	    public void viewEvents(int day) {
	        Day selectedDay = days[day - 1];
	        System.out.println("Events for " + name + ", Day " + selectedDay.getDayOfMonth() + ":");
	        for (Event event : selectedDay.getEvents()) {
	            if (event != null) {
	                System.out.println("- " + event.getName());
	            }
	        }
	    }
}
