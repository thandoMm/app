import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        shootingGun myShotgun = new shootingGun("Gun R5", 7);
        while (true) {
            System.out.println("1=======shoot========");
            System.out.println("2========reload=======");
            System.out.println("3==displayAmmunition==");


            System.out.println("Please enter your option :");
            Scanner sc = new Scanner(System.in);
            int option = sc.nextInt();

            switch (option) {
                case 1:
                    myShotgun.shoot();
                    break;
                case 2:
                    myShotgun.reload();
                    break;
                case 3:
                   myShotgun.displayAmmunition();
                    break;
                default:
                    System.out.println("Invalid option");
            }
        }
    }
}