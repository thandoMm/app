public class shootingGun {

    private String name;
    private int[] Ammunition;

    public shootingGun(String name, int max) {
        this.name = name;
        this.Ammunition = new int[max];

        loadAmmunition();
    }

    private void loadAmmunition() {
        for (int i = 0; i < Ammunition.length; i++) {
            Ammunition[i] = 1; // Representing loaded ammunition with 1
        }
    }

    public void shoot() {
        if (Ammunition.length > 0) {
            System.out.println("Shoot");
            Ammunition[Ammunition.length - 1] = 0; // Representing unloaded ammunition with 0
            displayAmmunition();
        } else {
            System.out.println("Please reload");
        }

    }

    public void reload() {
        System.out.println("Reloading " + name);
        loadAmmunition();
        displayAmmunition();
    }

    public void displayAmmunition() {
        System.out.print("Ammunition count: ");
        for (int ammo : Ammunition) {
            System.out.print(ammo == 1 ? "*" : "-"); 
        }
        System.out.println();
    }

}
